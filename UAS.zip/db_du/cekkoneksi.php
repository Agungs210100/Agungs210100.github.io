<?php
// mengaktifkan session pada php
session_start();

// menghubungkan php dengan koneksi database
include 'koneksi.php';

// menangkap data yang dikirim dari form login
$username = $_POST['username'];
$password = $_POST['password'];


// menyeleksi data user dengan username dan password yang sesuai
$login = mysqli_query($koneksi,"SELECT * FROM pengguna WHERE username='$username' and password='$password'");
// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($login);

// cek apakah username dan password di temukan pada database
if($cek > 0){

 $data = mysqli_fetch_assoc($login);

 if($data['level']=="Admin"){

  // buat session login dan username
  $_SESSION['username'] = $username;
  $_SESSION['level'] = "admin";
  // alihkan ke halaman dashboard admin
  header("location:hu.html");

 // cek jika user login sebagai pegawai
 }else if($data['level']=="Kaprodi"){
  // buat session login dan username
  $_SESSION['username'] = $username;
  $_SESSION['level'] = "kaprodi";
  // alihkan ke halaman dashboard pegawai
  header("location:halaman_utama.php");

 }else if($data['level']=="Dosen"){
  // buat session login dan username
  $_SESSION['username'] = $username;
  $_SESSION['level'] = "dosen";
  // alihkan ke halaman dashboard pegawai
  header("location:tampilguru.php");

 }else if($data['level']=="Mahasiswa"){
  // buat session login dan username
  $_SESSION['username'] = $username;
  $_SESSION['level'] = "mahasiswa";
  // alihkan ke halaman dashboard pegawai
  header("location:tampilsiswa.php");

 }else{

  // alihkan ke halaman login kembali
  header("location:index.php?pesan=gagal");
 } 
}else{
 header("location:index.php?pesan=gagal");
}

?>