<h3><a href="input_guru.html">Tambah Guru</a></h3>
<table border="1">
    <tr>
        <th>kd_siswa</th>
       
              <th>nis</th>
                <th>nama_siswa</th>
                <th>jenkel</th>
                <th>agama</th>
                <th>tempat_lahir</th>
                <th>tanggal_lahir</th>
                <th>alamat</th>
                <th>no_telp</th>
                <th>foto</th>
                <th>tahun_angkatan</th>
                <th>status</th>
        <th colspan="2">Aksi</th>
    </tr>
    <?php
    include "koneksi.php";

    $no = 1;
    $ambildata = mysqli_query($koneksi, "select * from tb_siswa");
    while ($tampil = mysqli_fetch_array($ambildata)) {
        echo "
        <tr>
            <td>$tampil[kd_siswa]</td>
            <td>$tampil[nis]</td>
            <td>$tampil[nama_siswa]</td>
            <td>$tampil[jenkel]</td>
            <td>$tampil[agama]</td>
            <td>$tampil[tempat_lahir]</td>
            <td>$tampil[tanggal_lahir]</td>
            <td>$tampil[alamat]</td>
            <td>$tampil[no_telp]</td>
            <td>$tampil[foto]</td>
            <td>$tampil[tahun_angkatan]</td>
            <td>$tampil[status]</td>
             <td><a href='delete.php?kode=$tampil[kd_siswa]'> Hapus </a></td>
            <td><a href='editsiswa.php?kode=$tampil[kd_siswa]'> Ubah </a></td>
        </tr>";
          $no++;


    }
    ?>
</table>
<a href=halaman_utama_admin.php>Back To Home</a>