<!DOCTYPE html>
<html lang="en">
<head>
    <title>Index</title>
    <link rel="stylesheet" href="as.css">
</head>
<body>
    <?php
 session_start();

 // cek apakah yang mengakses halaman ini sudah login
 if($_SESSION['level']==""){
  header("location:index.php?pesan=gagal");
 }

 ?>
 

 
    <nav>
        <div class="wrapper">
            <div class="logo"><a href=''>Halaman Utama Admin</a></div>
            <div class="menu">

                <ul>
                    <li><a href="#Home">Home</a></li>
                    <li><a href=http://localhost/db_du/input_guru.html>Input_guru</a></li>
                    <li><a href=http://localhost/db_du/inputsiswa.html>Input Siswa</a></li>
                    <li><a href=http://localhost/db_du/tampan.php>Tampil Data Guru</a></li>
                    <li><a href=http://localhost/db_du/tampilsiswa.php>Tampil Data Siswa</a></li>
                    <li><a href="" class="tbl-biru">Sign Up</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="wrapper">
        <section id="home">
            <img src="duu.jpg">
            <div class="kolom">
                <p>Halo <b><?php echo $_SESSION['username']; ?></b> Anda telah login sebagai <b><?php echo $_SESSION['level']; ?></b>.</p>
 
                <p class="deskripsi">SIAKAD SMK DARUL ULUM</p>
                <h2>Selamat Datang Di Website Sekolah DARUL ULUM</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium asperiores voluptate assumenda! Expedita, quidem. Porro provident excepturi minima molestias id corrupti veniam totam officia ipsam unde! Repellendus officiis enim illo.</p>
                <p><a href=""</a>
                    <a href="logout.php">LOGOUT</a></p>
            </div>
        </section>
    </div>
</body>
</html>