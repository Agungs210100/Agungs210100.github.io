<?php
include "koneksi.php";

if (isset($_GET['kode'])) {
    $kd_guru = $_GET['kode'];
    mysqli_query($koneksi, "delete  from tb_guru WHERE kd_guru=$kd_guru");
    header("Location: tampan.php");
}
